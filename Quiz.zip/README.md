# js-quiz-project
Eindopdracht JavaScript – Quiz Project
Risandro Agata

De quiz toont meerdere meerkeuzevragen op het scherm.
De gebruiker kiest per vraag een antwoord via knoppen.
Na elke keuze controleert de quiz of het antwoord goed of fout is en gaat daarna automatisch door naar de volgende vraag.
Aan het einde van de quiz wordt het eindresultaat (aantal correcte antwoorden) getoond.
